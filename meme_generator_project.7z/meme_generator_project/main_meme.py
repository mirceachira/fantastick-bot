
import requests
import string
import random
import generator

def main_generator(request):

	url = 'https://vignette.wikia.nocookie.net/dragonballfanon/images/7/70/Random.png/revision/latest?cb=20161221030547'
	r = requests.get(url, allow_redirects=True)
	s = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
	list_of_texts=[]
	list_of_texts.append(["when you want to give bonus points","but nobody volunteers as tribute"])
	list_of_texts.append(["when they think they are overworked" ,"but you're about to give them more homework" ])
	list_of_texts.append([ "when you think you told a good joke","but no stundent laughs" ])
	list_of_texts.append([ "when students start learning","just after failing their midterm" ])
	text=random.choice(list_of_texts)

	#list_of_texts.append([ , ])
	open(s+'.jpg', 'wb').write(r.content)
	generator.generate_meme(s+'.jpg',text[0],text[1])

	response = HttpResponse(content_type="image/jpeg")
	meme.save(response, "JPEG")
	return response

main_generator()
